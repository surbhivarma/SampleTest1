//
//  main.m
//  CocoaPodExample
//
//  Created by Surbhi_Varma on 6/4/15.
//  Copyright (c) 2015 Surbhi_Varma. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
